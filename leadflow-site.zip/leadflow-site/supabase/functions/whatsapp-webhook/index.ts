// Supabase Edge Function: whatsapp-webhook
// بيستقبل رسائل الواتساب من سيرفر الربط (Evolution API / WAHA) ويحوّل رسائل الجروبات المتابَعة
// لتحديثات مشاريع باسم صاحب الرقم. انشره بدون JWT لأن سيرفر الربط مش بيبعت JWT:
//   supabase functions deploy whatsapp-webhook --no-verify-jwt
import { createClient } from "npm:@supabase/supabase-js@2.45.4";
import { extract, guess } from "./parse.ts";

const MAX_PER_DAY = Number(Deno.env.get("MAX_WA_PER_DAY") ?? "500"); // حماية لو التوكن اتسرّب
const json = (o: unknown, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { "Content-Type": "application/json" } });
async function sha(s: string) {
  const h = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
  return [...new Uint8Array(h)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
// اختياري: لو ضفت ANTHROPIC_API_KEY كـ Secret، التصنيف بيتم بـ Claude. غير كده بالكلمات المفتاحية.
async function llm(t: string) {
  const k = Deno.env.get("ANTHROPIC_API_KEY"); if (!k) return null;
  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST", headers: { "x-api-key": k, "anthropic-version": "2023-06-01", "content-type": "application/json" },
      body: JSON.stringify({ model: Deno.env.get("ANTHROPIC_MODEL") ?? "claude-haiku-5-5", max_tokens: 100, messages: [{ role: "user", content: `رسالة واتساب عن مشروع عقاري. رجّع JSON فقط {"name":"اسم المشروع","type":"commercial|residential|other"}. commercial للمحلات والعيادات والمكاتب والمولات، residential للشقق والفلل والدوبلكس.\n${t.slice(0, 1500)}` }] }),
    });
    const j = await r.json();
    const o = JSON.parse(String(j.content?.[0]?.text ?? "").replace(/```json|```/g, "").trim());
    if (["commercial", "residential", "other"].includes(o.type)) return { name: String(o.name || "").slice(0, 40) || "مشروع", type: o.type as string };
  } catch (_) { /* نرجع للكلمات المفتاحية */ }
  return null;
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return json({ ok: true });
  const token = new URL(req.url).searchParams.get("token") ?? req.headers.get("x-token") ?? "";
  if (!/^[a-f0-9]{32,}$/.test(token)) return json({ error: "bad_token" }, 401);
  const c = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const { data: row } = await c.from("docs").select("id,data").eq("collection", "wa_meta").eq("data->>token", token).maybeSingle();
  if (!row) return json({ error: "bad_token" }, 401);
  const uid = row.id as string, meta = (row.data ?? {}) as Record<string, any>;
  const p = await req.json().catch(() => null);
  if (!p) return json({ error: "bad_json" }, 400);

  const m = extract(p);
  if (m.fromMe || !m.isGroup) return json({ ignored: "not_group_or_own" }); // الرسائل الخاصة بتتجاهل تمامًا
  const g = ((meta.allowed ?? []) as { id: string; name: string }[]).find((a) => a.id === m.chat);
  if (!g) { // نسجّل ظهور الجروب بس (من غير محتوى) عشان المستخدم يختار يتابعه
    const seen = { ...(meta.seen ?? {}) } as Record<string, any>;
    seen[m.chat] = { name: m.gname || seen[m.chat]?.name || "", at: Date.now() };
    const keep: Record<string, any> = {};
    Object.keys(seen).sort((a, b) => seen[b].at - seen[a].at).slice(0, 30).forEach((k) => keep[k] = seen[k]);
    await c.rpc("merge_doc", { c: "wa_meta", i: uid, patch: { seen: keep } });
    return json({ ignored: "group_not_followed" });
  }
  const text = m.text.trim();
  if (text.length < 15) return json({ ignored: "too_short" });
  const today = new Date().toISOString().slice(0, 10);
  const dayCount = meta.day === today ? (meta.dayCount ?? 0) : 0;
  if (dayCount >= MAX_PER_DAY) return json({ error: "daily_limit" }, 429);
  const info = (await llm(text)) ?? guess(text);
  const mid = m.mid || `${m.chat}|${text.slice(0, 40)}|${Math.floor(Date.now() / 60000)}`;
  const id = "wa" + (await sha(uid + mid)).slice(0, 24); // نفس الرسالة مرتين = تحديث واحد
  const { data: dup } = await c.from("docs").select("id").eq("collection", "updates").eq("id", id).maybeSingle();
  if (dup) return json({ ignored: "duplicate" }); // نفس الرسالة وصلت قبل كده
  const { error } = await c.from("docs").upsert({ collection: "updates", id, data: { text: text.slice(0, 2000), name: info.name, type: info.type, group: g.name || m.gname, at: Date.now(), by: uid, src: "whatsapp", mid } });
  if (error) return json({ error: error.message }, 500);
  await c.rpc("merge_doc", { c: "wa_meta", i: uid, patch: { count: (meta.count ?? 0) + 1, lastAt: Date.now(), day: today, dayCount: dayCount + 1 } });
  return json({ ok: true, type: info.type, name: info.name });
});
