// منطق نقي (من غير Deno) عشان يتختبر لوحده. بيفهم شكل رسائل WAHA وEvolution API وأي JSON بسيط.
export type Msg = { text: string; chat: string; mid: string; gname: string; isGroup: boolean; sender: string; fromMe: boolean };

export function extract(p: any): Msg {
  const m = p?.payload ?? p?.data ?? p ?? {};
  const text = m?.body ?? m?.text ?? m?.message?.conversation ?? m?.message?.extendedTextMessage?.text ?? m?.message?.imageMessage?.caption ?? "";
  const chat = m?.chatId ?? m?.key?.remoteJid ?? m?.from ?? m?.group ?? "";
  const mid = m?.id?._serialized ?? (typeof m?.id === "string" ? m.id : "") ?? "";
  const gname = m?.groupName ?? m?.chatName ?? m?._data?.groupName ?? p?.groupName ?? "";
  const fromMe = !!(m?.fromMe ?? m?.key?.fromMe);
  const sender = m?._data?.notifyName ?? m?.pushName ?? p?.pushName ?? "";
  const isGroup = String(chat).endsWith("@g.us") || p?.isGroup === true;
  return { text: String(text ?? ""), chat: String(chat), mid: String(mid || m?.key?.id || ""), gname: String(gname), isGroup, sender: String(sender), fromMe };
}

const KC = /تجاري|تجارية|محل|محلات|مول|عيادة|عيادات|مكتب|مكاتب|إداري|اداري|كافيه|ريتيل|commercial|retail|shop|office|clinic|mall/gi;
const KR = /سكني|سكنية|شقة|شقق|دوبلكس|فيلا|فيلات|تاون هاوس|توين هاوس|كمبوند|استوديو|residential|apartment|villa|duplex/gi;

export function guess(t: string) {
  const name = (t.split(/[:：\n]/)[0] || "").replace(/^(تحديث|جديد|عاجل)\s*(مشروع)?\s*/, "").trim().slice(0, 40);
  const c = (t.match(KC) || []).length, r = (t.match(KR) || []).length;
  return { name: name || "مشروع", type: c > r ? "commercial" : r > c ? "residential" : "other" };
}
