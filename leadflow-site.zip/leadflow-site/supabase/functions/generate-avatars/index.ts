// Supabase Edge Function: generate-avatars
// ياخد صورة المستخدم المحفوظة ويولّد 5 شخصيات كرتون 3D بنفس الملامح، ويخزنها في Storage.
// المفتاح بيتحط كـ Secret على السيرفر بس (مش في الموقع أبدًا):
//   supabase secrets set OPENAI_API_KEY=sk-...
import { createClient } from "npm:@supabase/supabase-js@2.45.4";

const KEY = Deno.env.get("OPENAI_API_KEY");
const MODEL = Deno.env.get("IMAGE_MODEL") ?? "gpt-image-1"; // أي موديل بيدعم صور مرجعية (edits)
const MAX_PER_DAY = Number(Deno.env.get("MAX_GENS_PER_DAY") ?? "3");
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type" };
const json = (o: unknown, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { ...cors, "Content-Type": "application/json" } });

const STYLE = "High-quality 3D cartoon illustration, Pixar-like, premium dark charcoal and gold cinematic lighting. No text, no letters, no logos, no watermark.";
const SAME = "The SAME person as in the reference images: the first image is the approved cartoon character, keep exactly his face shape, hairstyle, skin tone, facial hair, glasses and age. Only the pose, expression, outfit and scene change.";
const SCENES: Record<string, string> = {
  cold: "He looks confused, lost and cold: winter coat and scarf, holding a paper map, pockets turned inside out, standing near unfinished concrete real estate buildings at dusk, bluish cold tones.",
  total: "He is a successful real estate professional in a navy suit, holding a black leads folder and making a small victory fist, standing in front of a premium real estate development with palm trees at golden hour.",
  hot: "He looks confident and happy, leaning out of the window of a luxury black car with a thumbs up, upscale real estate buildings in the background, red-orange sunset.",
  warm: "He is talking on a mobile phone while holding a property brochure, wearing a beige blazer over a black turtleneck, in front of a modern residential compound at warm dusk.",
  late: "He points his index finger at his own temple as if reminding himself to think and follow up. Beside him sits a friendly, expressive cartoon alarm clock character with a face, clearly visible, plus a follow-up clipboard (no readable text) on a desk.",
};

const sb = () => createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
async function getDoc(c: ReturnType<typeof sb>, col: string, id: string) {
  const { data } = await c.from("docs").select("data").eq("collection", col).eq("id", id).maybeSingle();
  return (data?.data ?? {}) as Record<string, any>;
}
const putDoc = (c: ReturnType<typeof sb>, col: string, id: string, data: unknown) =>
  c.from("docs").upsert({ collection: col, id, data });
async function sha(s: string) {
  const h = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
  return [...new Uint8Array(h)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
function dataUrlToBlob(u: string) {
  const [h, b] = u.split(",");
  const type = /data:([^;]+)/.exec(h)?.[1] ?? "image/jpeg";
  return new Blob([Uint8Array.from(atob(b), (c) => c.charCodeAt(0))], { type });
}
async function edit(images: Blob[], prompt: string, size: string): Promise<Uint8Array> {
  const fd = new FormData();
  fd.append("model", MODEL); fd.append("prompt", prompt); fd.append("size", size);
  fd.append("quality", "medium"); fd.append("input_fidelity", "high");
  images.forEach((b, i) => fd.append("image[]", b, `ref${i}.${b.type.includes("jpeg") ? "jpg" : "png"}`));
  const r = await fetch("https://api.openai.com/v1/images/edits", { method: "POST", headers: { Authorization: `Bearer ${KEY}` }, body: fd });
  const j = await r.json();
  if (!r.ok) throw new Error(j?.error?.message ?? `HTTP ${r.status}`);
  return Uint8Array.from(atob(j.data[0].b64_json), (c) => c.charCodeAt(0));
}

async function run(uid: string, hash: string) {
  const c = sb();
  try {
    const row = await getDoc(c, "avatars", uid);
    const photo = dataUrlToBlob(row.photo);
    // 1) شخصية أساسية من الصورة، ثم 2) كل المشاهد بتعتمد عليها وعلى الصورة الأصلية لتثبيت الملامح
    const portrait = await edit([photo], `${STYLE} Turn the person in the reference photo into a 3D cartoon character, head-and-shoulders portrait, friendly neutral smile, plain dark charcoal background. Preserve identity: face shape, skin tone, hairstyle, facial hair, glasses, age.`, "1024x1024");
    const refs = [new Blob([portrait], { type: "image/png" }), photo];
    const keys = Object.keys(SCENES);
    const out = await Promise.all(keys.map((k) => edit(refs, `${STYLE} ${SAME} Scene: ${SCENES[k]}`, "1536x1024")));
    const imgs: Record<string, string> = {};
    for (let i = 0; i < keys.length; i++) {
      const path = `${uid}/${hash.slice(0, 10)}-${keys[i]}.png`;
      const { error } = await c.storage.from("avatars").upload(path, out[i], { contentType: "image/png", upsert: true });
      if (error) throw new Error(error.message);
      imgs[keys[i]] = c.storage.from("avatars").getPublicUrl(path).data.publicUrl;
    }
    // تنضيف الصور القديمة (خصوصية + تكلفة)
    const { data: old } = await c.storage.from("avatars").list(uid);
    const stale = (old ?? []).filter((f) => !f.name.startsWith(hash.slice(0, 10))).map((f) => `${uid}/${f.name}`);
    if (stale.length) await c.storage.from("avatars").remove(stale);
    const cur = await getDoc(c, "avatars", uid);
    await putDoc(c, "avatars", uid, { ...cur, imgs, hash, status: "ready", err: "", at: Date.now() });
  } catch (e) {
    const cur = await getDoc(c, "avatars", uid); // الصور القديمة بتفضل زي ما هي
    await putDoc(c, "avatars", uid, { ...cur, status: "error", err: String((e as Error).message).slice(0, 160) });
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  const c = sb();
  const jwt = (req.headers.get("Authorization") ?? "").replace("Bearer ", "");
  const { data: { user } } = await c.auth.getUser(jwt);
  if (!user) return json({ error: "unauthorized" }, 401);
  const body = await req.json().catch(() => ({}));
  const uid = user.id;

  if (body.action === "remove") {
    const { data: files } = await c.storage.from("avatars").list(uid);
    if (files?.length) await c.storage.from("avatars").remove(files.map((f) => `${uid}/${f.name}`));
    const cur = await getDoc(c, "avatars", uid); // نحافظ على شكل الشخصية (look)
    await putDoc(c, "avatars", uid, { ...cur, photo: "", imgs: {}, hash: "", status: "idle", err: "" });
    return json({ ok: true });
  }
  if (!KEY) return json({ error: "OPENAI_API_KEY not configured" }, 500);
  const row = await getDoc(c, "avatars", uid);
  if (!row.photo) return json({ error: "no_photo" }, 400);
  const hash = await sha(row.photo);
  if (!body.force && row.hash === hash && row.status === "ready") return json({ status: "ready", cached: true }); // كاش: نفس الصورة = مفيش تكلفة تاني

  // حد يومي لكل مستخدم (محفوظ في collection مش بيكتب فيه العميل)
  const meta = await getDoc(c, "avatar_meta", uid);
  const gens = ((meta.gens ?? []) as number[]).filter((t) => t > Date.now() - 864e5);
  if (gens.length >= MAX_PER_DAY) return json({ error: "rate_limit" }, 429);
  await putDoc(c, "avatar_meta", uid, { gens: [...gens, Date.now()] });
  await putDoc(c, "avatars", uid, { ...row, status: "pending", err: "" });
  // @ts-ignore EdgeRuntime متاح في Supabase Edge
  EdgeRuntime.waitUntil(run(uid, hash));
  return json({ status: "pending" }, 202);
});
