// Supabase Edge Function: generate-hooks
// بياخد اسم المشروع (+ معلومات اختيارية) ويرجّع 5 هوكس إعلانية من ChatGPT (OpenAI).
// المفتاح Secret على السيرفر بس:  supabase secrets set OPENAI_API_KEY=sk-...
import { createClient } from "npm:@supabase/supabase-js@2.45.4";

const KEY = Deno.env.get("OPENAI_API_KEY");
const MODEL = Deno.env.get("OPENAI_TEXT_MODEL") ?? "gpt-4o-mini";
const MAX_PER_DAY = Number(Deno.env.get("MAX_HOOKS_PER_DAY") ?? "30");
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type" };
const json = (o: unknown, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  const c = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const { data: { user } } = await c.auth.getUser((req.headers.get("Authorization") ?? "").replace("Bearer ", ""));
  if (!user) return json({ error: "unauthorized" }, 401);
  if (!KEY) return json({ error: "OPENAI_API_KEY غير مضبوط على السيرفر" }, 500);

  const b = await req.json().catch(() => ({}));
  const name = String(b.name ?? "").trim().slice(0, 80), info = String(b.info ?? "").trim().slice(0, 600);
  if (!name) return json({ error: "اكتب اسم المشروع" }, 400);

  // حد يومي لكل مستخدم (في collection الكتابة فيها للسيرفر بس)
  const { data: row } = await c.from("docs").select("data").eq("collection", "hook_meta").eq("id", user.id).maybeSingle();
  const t = ((row?.data?.t ?? []) as number[]).filter((x) => x > Date.now() - 864e5);
  if (t.length >= MAX_PER_DAY) return json({ error: "وصلت للحد اليومي، جرّب بكرة" }, 429);
  await c.from("docs").upsert({ collection: "hook_meta", id: user.id, data: { t: [...t, Date.now()] } });

  const prompt = `اكتب 5 هوكس (أول جملة في إعلان فيسبوك/إنستجرام) لمشروع عقاري اسمه "${name}".${info ? "\nمعلومات عن المشروع: " + info : ""}
باللهجة المصرية، كل هوك جملة قصيرة (أقل من 15 كلمة) وبزاوية مختلفة: سؤال، عرض أو رقم، ندرة أو وقت، حلم وأسلوب حياة، استثمار.
ماتألفش أسعار أو أرقام أو مميزات مش مذكورة في المعلومات. رجّع JSON فقط بالشكل {"hooks":["..",".."]}`;
  const r = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST", headers: { Authorization: `Bearer ${KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ model: MODEL, temperature: 0.9, response_format: { type: "json_object" },
      messages: [{ role: "system", content: "أنت كاتب إعلانات عقارية محترف في السوق المصري." }, { role: "user", content: prompt }] }),
  });
  const j = await r.json();
  const refund = () => c.from("docs").upsert({ collection: "hook_meta", id: user.id, data: { t } }); // المحاولة الفاشلة مبتتحسبش
  if (!r.ok) { await refund(); return json({ error: j?.error?.message ?? `HTTP ${r.status}` }, 502); }
  try {
    const o = JSON.parse(j.choices[0].message.content);
    const hooks = (o.hooks as unknown[]).filter((h) => typeof h === "string" && h.trim()).map((h) => String(h).trim().slice(0, 200)).slice(0, 8);
    if (!hooks.length) throw new Error("empty");
    return json({ hooks });
  } catch (_) { await refund(); return json({ error: "رد غير متوقع من الموديل، جرّب تاني" }, 502); }
});
